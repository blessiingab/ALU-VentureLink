// applications_screen.dart

