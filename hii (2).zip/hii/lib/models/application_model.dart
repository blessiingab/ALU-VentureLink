// application_model.dart

