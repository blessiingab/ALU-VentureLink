// event_model.dart

